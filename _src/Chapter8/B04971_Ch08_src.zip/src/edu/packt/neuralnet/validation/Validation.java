package edu.packt.neuralnet.validation;

import edu.packt.neuralnet.NeuralNet;

public interface Validation {

	public double[][] netValidation(NeuralNet n);
	
}
