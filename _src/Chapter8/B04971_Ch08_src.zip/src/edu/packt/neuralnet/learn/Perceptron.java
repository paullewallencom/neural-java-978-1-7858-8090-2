package edu.packt.neuralnet.learn;

import edu.packt.neuralnet.NeuralNet;

public class Perceptron extends Training {

	public NeuralNet train(NeuralNet n){
		
		return super.train(n);
		
	}
	
}
